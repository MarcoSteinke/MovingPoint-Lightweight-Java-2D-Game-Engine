public class Colour extends java.awt.Color {
    Colour(int r, int g, int b) {
        super(r,g,b);    
    }
    
    Colour(int rgb) {
        super(rgb);    
    }
}
